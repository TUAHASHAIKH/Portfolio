export function About() {
  return (
    <section id="about-me" className="py-20 px-6 relative">
      <div className="max-w-6xl mx-auto">
        <h2 className="text-4xl font-bold text-foreground mb-12">
          <span className="text-accent">#</span>about-me
          <div className="w-44 h-1 bg-accent mt-2"></div>
        </h2>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          {/* Left content */}
          <div className="space-y-6">
            <div>
              <p className="text-foreground text-lg mb-4">Hello, i'm Elias!</p>
              <p className="text-foreground/80 leading-relaxed">
                I'm a self-taught front-end developer based in Kyiv, Ukraine. I
                can develop responsive websites from scratch and raise them into
                modern user-friendly web experiences.
              </p>
            </div>

            <p className="text-foreground/80 leading-relaxed">
              Transforming my creativity and knowledge into a websites has been
              my passion for over a year. I have been helping various clients to
              establish their presence online. I always strive to learn about the
              newest technologies and frameworks.
            </p>

            <button className="border border-accent text-accent hover:bg-accent hover:text-accent-foreground transition-colors px-6 py-3 text-sm font-mono rounded">
              Read more <span className="text-accent">→</span>
            </button>
          </div>

          {/* Right side - Image placeholder with decorative elements */}
          <div className="relative h-96 flex items-center justify-center">
            {/* Profile image placeholder */}
            <div className="absolute inset-0 flex items-center justify-center">
              <div className="w-64 h-80 bg-gradient-to-br from-background to-secondary border border-border rounded-lg flex items-center justify-center text-foreground/50">
                [Profile Image]
              </div>
            </div>

            {/* Decorative dot pattern - right side */}
            <div className="absolute right-0 top-0 space-y-2">
              {Array.from({ length: 6 }).map((_, i) => (
                <div key={i} className="flex gap-2">
                  {Array.from({ length: 5 }).map((_, j) => (
                    <div
                      key={j}
                      className="w-1.5 h-1.5 rounded-full bg-accent"
                    ></div>
                  ))}
                </div>
              ))}
            </div>

            {/* Bottom decorative lines */}
            <div className="absolute bottom-0 right-1/4 w-32 h-1 bg-gradient-to-r from-accent to-transparent"></div>
          </div>
        </div>
      </div>

      {/* Left side decorative border */}
      <div className="absolute left-0 top-1/4 bottom-1/4 border-l border-border hidden lg:block"></div>
    </section>
  )
}
