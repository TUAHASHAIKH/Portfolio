export function Contacts() {
  return (
    <section id="contacts" className="py-20 px-6">
      <div className="max-w-6xl mx-auto">
        <h2 className="text-4xl font-bold text-foreground mb-12">
          <span className="text-accent">#</span>contacts
          <div className="w-32 h-1 bg-accent mt-2"></div>
        </h2>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          {/* Left content */}
          <div className="space-y-6">
            <p className="text-foreground/80 leading-relaxed">
              I'm interested in freelance opportunities. However, if you have
              other request or question, don't hesitate to contact me
            </p>
          </div>

          {/* Right content - Contact box */}
          <div className="border border-border rounded-lg p-8">
            <h3 className="text-foreground font-bold mb-6">Message me here</h3>

            <div className="space-y-4">
              <div className="flex items-center gap-3">
                <span className="text-accent text-lg">👾</span>
                <span className="text-foreground font-mono">!Elias#3519</span>
              </div>
              <div className="flex items-center gap-3">
                <span className="text-accent text-lg">✉️</span>
                <span className="text-foreground font-mono">elias@elias.me</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Decorative dot pattern - left side */}
      <div className="absolute left-6 top-1/3 space-y-2 hidden lg:block">
        {Array.from({ length: 5 }).map((_, i) => (
          <div key={i} className="flex gap-2">
            {Array.from({ length: 2 }).map((_, j) => (
              <div
                key={j}
                className="w-1.5 h-1.5 rounded-full bg-accent/30"
              ></div>
            ))}
          </div>
        ))}
      </div>
    </section>
  )
}
