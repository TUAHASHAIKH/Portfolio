export function Projects() {
  const projects = [
    {
      id: 1,
      title: 'ChertNodes',
      description: 'Minecraft servers hosting',
      tags: ['HTML', 'SCSS', 'Python', 'Flask'],
      buttons: ['Live', 'Cached'],
    },
    {
      id: 2,
      title: 'ProtectX',
      description: 'Discord anti-crash bot',
      tags: ['HTML', 'SCSS', 'Python', 'Flask'],
      buttons: ['Live'],
    },
    {
      id: 3,
      title: 'Kahoot Answers Viewer',
      description: 'Get answers to your kahoot quiz',
      tags: ['CSS', 'Express', 'Node.js'],
      buttons: ['Live'],
    },
  ]

  return (
    <section id="works" className="py-20 px-6">
      <div className="max-w-6xl mx-auto">
        <div className="flex items-center justify-between mb-16">
          <h2 className="text-4xl font-bold text-foreground">
            <span className="text-accent">#</span>projects
            <div className="w-32 h-1 bg-accent mt-2"></div>
          </h2>
          <button className="text-foreground hover:text-accent transition-colors text-sm">
            View all <span className="text-accent">→</span>
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {projects.map((project) => (
            <div
              key={project.id}
              className="border border-border rounded-lg overflow-hidden hover:border-accent transition-colors"
            >
              {/* Project image placeholder */}
              <div className="bg-gradient-to-br from-background to-secondary h-48 flex items-center justify-center text-center text-foreground/50">
                [Project Image Placeholder]
              </div>

              <div className="p-6 border-t border-border">
                <div className="flex gap-2 mb-4 flex-wrap">
                  {project.tags.map((tag) => (
                    <span
                      key={tag}
                      className="text-xs text-foreground/70 font-mono"
                    >
                      {tag}
                    </span>
                  ))}
                </div>

                <h3 className="text-xl font-bold text-foreground mb-2">
                  {project.title}
                </h3>

                <p className="text-foreground/70 text-sm mb-6">
                  {project.description}
                </p>

                <div className="flex gap-3">
                  {project.buttons.map((btn) => (
                    <button
                      key={btn}
                      className="border border-accent text-accent hover:bg-accent hover:text-accent-foreground transition-colors px-4 py-2 text-xs font-mono rounded"
                    >
                      {btn} <span className="text-accent">↔</span>
                    </button>
                  ))}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Decorative dot pattern - left side */}
      <div className="absolute left-6 top-1/2 space-y-2 hidden lg:block">
        {Array.from({ length: 5 }).map((_, i) => (
          <div key={i} className="flex gap-2">
            {Array.from({ length: 2 }).map((_, j) => (
              <div
                key={j}
                className="w-1.5 h-1.5 rounded-full bg-accent/30"
              ></div>
            ))}
          </div>
        ))}
      </div>
    </section>
  )
}
