export function Skills() {
  const skillCategories = [
    {
      title: 'Languages',
      skills: ['TypeScript Lua', 'Python JavaScript'],
    },
    {
      title: 'Databases',
      skills: ['SQLite PostgreSQL', 'Mongo'],
    },
    {
      title: 'Tools',
      skills: ['VSCode Neovim Linux', 'Figma XFCE Arch', 'Git Font Awesome'],
    },
    {
      title: 'Other',
      skills: ['HTML CSS EJS SCSS', 'REST Jinja'],
    },
    {
      title: 'Frameworks',
      skills: ['React Vue', 'Disnake Discord.js', 'Flask Express.js'],
    },
  ]

  return (
    <section className="py-20 px-6 relative" id="skills">
      <div className="max-w-7xl mx-auto">
        <h2 className="text-4xl font-bold text-foreground mb-12">
          <span className="text-accent">#</span>skills
          <div className="w-64 h-1 bg-accent mt-2"></div>
        </h2>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4 mt-12">
          {skillCategories.map((category) => (
            <div
              key={category.title}
              className="border border-border bg-background hover:border-accent transition-colors p-5"
            >
              <h3 className="text-base font-bold text-foreground mb-4 font-mono">
                {category.title}
              </h3>
              <div className="space-y-2">
                {category.skills.map((skillGroup, idx) => (
                  <p key={idx} className="text-foreground/80 font-mono text-xs leading-relaxed">
                    {skillGroup}
                  </p>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Decorative elements - left side */}
      <div className="absolute left-12 top-32 hidden lg:block space-y-12">
        {/* Top dot pattern grid */}
        <div className="space-y-2">
          {Array.from({ length: 5 }).map((_, i) => (
            <div key={i} className="flex gap-2">
              {Array.from({ length: 5 }).map((_, j) => (
                <div
                  key={j}
                  className="w-1 h-1 rounded-full bg-accent/40"
                ></div>
              ))}
            </div>
          ))}
        </div>

        {/* Nested rectangles */}
        <div className="relative w-24 h-24">
          <div className="absolute inset-0 border border-accent/40 w-24 h-24"></div>
          <div className="absolute inset-3 border border-accent/50 w-16 h-16"></div>
          <div className="absolute inset-6 border border-accent/60 w-10 h-10"></div>
        </div>

        {/* Single square */}
        <div className="border border-accent/40 w-16 h-16"></div>
      </div>

      {/* Decorative elements - center */}
      <div className="absolute left-1/2 top-1/3 hidden lg:block space-y-8">
        {/* Dot pattern */}
        <div className="space-y-2">
          {Array.from({ length: 4 }).map((_, i) => (
            <div key={i} className="flex gap-2">
              {Array.from({ length: 5 }).map((_, j) => (
                <div
                  key={j}
                  className="w-1 h-1 rounded-full bg-accent/30"
                ></div>
              ))}
            </div>
          ))}
        </div>

        {/* Square */}
        <div className="border border-accent/30 w-14 h-14 ml-8"></div>
      </div>
    </section>
  )
}
