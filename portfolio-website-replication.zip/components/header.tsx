'use client'

import { ThemeToggle } from './theme-toggle'
import Link from 'next/link'

export function Header() {
  const scrollToSection = (id: string) => {
    const element = document.getElementById(id)
    element?.scrollIntoView({ behavior: 'smooth' })
  }

  return (
    <header className="fixed top-0 left-0 right-0 z-50 bg-background/80 backdrop-blur-sm border-b border-border">
      <div className="max-w-6xl mx-auto px-6 py-4 flex items-center justify-between">
        <Link href="#" className="text-xl font-bold text-foreground">
          ⬜ Elias
        </Link>

        <nav className="flex items-center gap-8">
          <button
            onClick={() => scrollToSection('home')}
            className="text-accent hover:text-accent-foreground transition-colors text-sm"
          >
            #home
          </button>
          <button
            onClick={() => scrollToSection('works')}
            className="text-foreground hover:text-accent transition-colors text-sm"
          >
            #works
          </button>
          <button
            onClick={() => scrollToSection('about-me')}
            className="text-foreground hover:text-accent transition-colors text-sm"
          >
            #about-me
          </button>
          <button
            onClick={() => scrollToSection('contacts')}
            className="text-foreground hover:text-accent transition-colors text-sm"
          >
            #contacts
          </button>
          <ThemeToggle />
        </nav>
      </div>
    </header>
  )
}
