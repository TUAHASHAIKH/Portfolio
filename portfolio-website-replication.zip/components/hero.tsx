export function Hero() {
  return (
    <section id="home" className="min-h-screen flex items-center pt-20 px-6 relative">
      <div className="max-w-7xl mx-auto w-full">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 items-center relative">
          {/* Left side - Text */}
          <div className="lg:col-span-1 space-y-8">
            <div className="space-y-2">
              <h1 className="text-6xl lg:text-7xl font-bold text-foreground leading-tight">
                Elias is a
              </h1>
              <h1 className="text-6xl lg:text-7xl font-bold leading-tight">
                <span className="text-accent">web designer</span> and
              </h1>
              <h1 className="text-6xl lg:text-7xl font-bold text-accent leading-tight">
                front-end developer
              </h1>
            </div>
            
            <p className="text-foreground/80 text-base leading-relaxed font-mono">
              He crafts responsive websites where technologies meet creativity
            </p>

            <button className="border border-accent text-accent hover:bg-accent hover:text-accent-foreground transition-colors px-6 py-3 text-sm font-mono">
              Contact me !!
            </button>
          </div>

          {/* Center - Decorative elements */}
          <div className="hidden lg:flex lg:col-span-1 relative h-96 items-center justify-center">
            {/* Decorative geometric shapes */}
            <div className="absolute space-y-6">
              {/* Top rectangle */}
              <div className="border border-accent w-32 h-24"></div>

              {/* Overlapping rectangles */}
              <div className="relative w-40 h-32 -ml-8">
                <div className="absolute border border-accent w-32 h-24 top-0 left-0"></div>
                <div className="absolute border border-accent w-24 h-20 bottom-0 right-0"></div>
              </div>
            </div>

            {/* Dot patterns center */}
            <div className="absolute right-12 space-y-2">
              {Array.from({ length: 5 }).map((_, i) => (
                <div key={i} className="flex gap-2">
                  {Array.from({ length: 5 }).map((_, j) => (
                    <div
                      key={j}
                      className="w-1 h-1 rounded-full bg-accent/60"
                    ></div>
                  ))}
                </div>
              ))}
            </div>
          </div>

          {/* Right side - Image placeholder */}
          <div className="lg:col-span-1 relative h-96 flex items-center justify-end">
            <div className="w-72 h-80 border border-border rounded-lg bg-foreground/5 flex items-center justify-center overflow-hidden relative">
              <div className="absolute inset-0 bg-gradient-to-br from-accent/10 via-transparent to-transparent"></div>
              <div className="text-foreground/40 font-mono text-sm z-10">[Image]</div>
            </div>
          </div>
        </div>
      </div>

      {/* Quote section */}
      <div className="max-w-6xl mx-auto w-full mt-32 border border-border rounded-lg p-8 relative">
        <div className="absolute -top-6 -left-6 text-6xl text-accent/30">"</div>
        <p className="text-xl text-foreground font-mono">
          With great power comes great electricity bill
        </p>
        <p className="text-right mt-6 text-foreground">- Dr. Who</p>
        <div className="absolute -bottom-6 -right-6 text-6xl text-accent/30">"</div>
      </div>
    </section>
  )
}
